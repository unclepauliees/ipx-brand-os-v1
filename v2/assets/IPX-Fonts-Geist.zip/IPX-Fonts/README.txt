IPX typeface: Geist (Vercel / Basement Studio), SIL Open Font License 1.1.
Geist Black (900) = headlines. Geist Regular/Medium/SemiBold = text and CTAs. Geist Mono = small labels.
Install the TTFs, or use the Variable files in design tools. Web: Google Fonts "Geist" and "Geist Mono".

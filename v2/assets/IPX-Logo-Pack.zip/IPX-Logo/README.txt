IPX LOGO PACK — Brand OS v2 (Nov 2026)

Primary: IPX-Mark-White-Ember (white IP + red-to-amber brush X) on IPX Black #000000.
On a light surface: IPX-Mark-Black-Ember. Mono (one colour) variants only where the gradient cannot print.
IPX-X-Icon-Ember: the brush X alone, for favicons and small marks.
IPX-PFP-Square-4096: the X / social profile picture (gold-check accounts render square).
Source/: Illustrator master and the original SVG master (black).

Rules: never redraw, recolour, outline, rotate or add effects to the mark. Clear space = the height of the I on all sides.
Minimum size 24 px tall on screen. Gradient X stops: #EF4136 -> #FBB040.
